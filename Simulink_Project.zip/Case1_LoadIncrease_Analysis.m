% Frequency response analysis - Case 1

% Maximum and minimum deviation
max_dev = max(y);
min_dev = min(y);

% Maximum absolute deviation
peak_dev = max(abs(y));

% Convert per-unit deviation to Hz
peak_Hz = peak_dev * 50;

% Steady-state error (average of final 5 seconds)
idx_final = t >= (max(t)-5);
steady_error = mean(y(idx_final));

% Settling time using 2% of peak deviation
tolerance = 0.02 * peak_dev;
idx = find(abs(y) > tolerance);

if isempty(idx)
    settling_time = 0;
else
    settling_time = t(idx(end));
end

% Display results
fprintf('\nCASE 1: LOAD INCREASE\n');
fprintf('Maximum deviation: %.8f pu\n', max_dev);
fprintf('Minimum deviation: %.8f pu\n', min_dev);
fprintf('Peak deviation: %.8f Hz\n', peak_Hz);
fprintf('Settling time: %.4f seconds\n', settling_time);
fprintf('Steady-state error: %.10f pu\n', steady_error);