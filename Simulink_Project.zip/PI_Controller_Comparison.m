clear;
clc;
close all;

s = tf('s');

H = 5;
D = 1;
Tg = 0.2;
Tt = 0.5;
R = 0.05;

Ggov = 1/(Tg*s+1);
Gtur = 1/(Tt*s+1);
Ggen = 1/(2*H*s+D);

Q = Ggov*Gtur*Ggen;
Gref = Q/(1+Q/R);

% Integral controller
Ki = 9.89387;
CI = Ki/s;

% Genuine PI controller - initial test
Kp = 1;
CPI = Kp + Ki/s;

% Closed-loop reference responses
TI = feedback(CI*Gref,1);
TPI = feedback(CPI*Gref,1);

% Check stability
disp('Integral controller stability:');
isstable(TI)

disp('PI controller stability:');
isstable(TPI)

% Compare responses
figure;

step(TI,TPI,100);

grid on;

legend('Integral controller','PI controller');

title('Comparison of Integral and PI Controllers');

xlabel('Time (seconds)');
ylabel('Frequency response');
%% Performance comparison

info_I = stepinfo(TI);
info_PI = stepinfo(TPI);

disp('INTEGRAL CONTROLLER PERFORMANCE');

disp(info_I);

disp('PI CONTROLLER PERFORMANCE');

disp(info_PI);

%% Stability comparison

disp('Integral controller poles:');
pole(TI)

disp('PI controller poles:');
pole(TPI)

%% Steady-state values

disp('Integral controller steady-state value:');
dcgain(TI)

disp('PI controller steady-state value:');
dcgain(TPI)