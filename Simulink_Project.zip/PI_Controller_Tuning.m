s = tf('s');

H = 5;
D = 1;
Tg = 0.2;
Tt = 0.5;
R = 0.05;

Ggov = 1/(Tg*s+1);
Gtur = 1/(Tt*s+1);
Ggen = 1/(2*H*s+D);

Q = Ggov*Gtur*Ggen;

Gref = Q/(1+Q/R);

pidtune(Gref,'PI')