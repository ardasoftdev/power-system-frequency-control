%% Corrected single-area 50 Hz load-frequency control model
% MATLAB R2026 + Control System Toolbox
% Simplified small-signal per-unit model. Parameters are provisional.
clear; clc; close all;

%% 1. Parameters
H = 5;       % s
D = 1;       % pu/pu
Tg = 0.2;    % s
Tt = 0.5;    % s
R = 0.05;    % pu/pu
s = tf('s');

%% 2. Component models and droop-closed plant
Ggov = 1/(Tg*s + 1);
Gtur = 1/(Tt*s + 1);
Ggen = 1/(2*H*s + D);

% Define Q = Ggov*Gtur*Ggen.
% Frequency feedback through governor droop gives denominator 1 + Q/R.
Q = minreal(Ggov*Gtur*Ggen);
Gref  = minreal(Q/(1 + Q/R));       % Delta-f / Delta-Pref
Gdist = minreal(Ggen/(1 + Q/R));    % Delta-f / Delta-Pnet

%% 3. PI tuning
% Tune PI against the reference-to-frequency plant.
[Cpi, tuneInfo] = pidtune(Gref, 'PI');
Kp = Cpi.Kp;
Ki = Cpi.Ki;
fprintf('PI gains from pidtune: Kp = %.6g, Ki = %.6g\n', Kp, Ki);
disp(tuneInfo);

% Correct disturbance closed-loop transfer:
% Delta-f / Delta-Pnet = Gdist / (1 + Cpi*Gref)
% (Do not use feedback(Gdist,Cpi*Gref), which adds an extra Gdist factor.)
Gcl = minreal(Gdist/(1 + Cpi*Gref));

fprintf('Closed-loop stable: %d\n', isstable(Gcl));

%% 4. Disturbance signals; net power = generation - load
t = (0:0.01:120)';
dLoadUp   = -0.05*(t >= 1);
dLoadDown =  0.05*(t >= 1);
dPVWind   = -0.03*(t >= 1) + 0.02*(t >= 25);
dCombined =  0.04*(t >= 1) - 0.02*(t >= 20) - 0.02*(t >= 40);

d = {dLoadUp, dLoadDown, dPVWind, dCombined};
names = {'Load increase','Load decrease','Renewable variation','Combined disturbances'};

figure('Color','w','Name','Corrected PI frequency responses');
tiledlayout(2,2);
for k = 1:4
    df = lsim(Gcl,d{k},t);          % per-unit frequency deviation
    fHz = 50 + 50*df;              % assumes 50 Hz base frequency
    nexttile;
    plot(t,fHz,'LineWidth',1.4); hold on;
    yline(50,'--');
    grid on; xlabel('Time (s)'); ylabel('Frequency (Hz)');
    title(names{k});
    fprintf('\n%s:\n',names{k});
    fprintf('  Minimum = %.6f Hz\n',min(fHz));
    fprintf('  Maximum = %.6f Hz\n',max(fHz));
    fprintf('  Final at %g s = %.6f Hz\n',t(end),fHz(end));
end
sgtitle(sprintf('PI-controlled response: Kp=%.4g, Ki=%.4g',Kp,Ki));

%% 5. Parameter uncertainty test, fixed nominal PI gains
factors = [0.8 1.0 1.2];
figure('Color','w','Name','Uncertainty test'); hold on; grid on;
for k = 1:numel(factors)
    a = factors(k);
    Ggov_k = 1/(a*Tg*s + 1);
    Gtur_k = 1/(a*Tt*s + 1);
    Ggen_k = 1/(2*(a*H)*s + a*D);
    Qk = minreal(Ggov_k*Gtur_k*Ggen_k);
    Gref_k = minreal(Qk/(1 + Qk/R));
    Gdist_k = minreal(Ggen_k/(1 + Qk/R));
    Gcl_k = minreal(Gdist_k/(1 + Cpi*Gref_k));
    df_k = lsim(Gcl_k,dCombined,t);
    plot(t,50+50*df_k,'LineWidth',1.4,...
        'DisplayName',sprintf('Parameters x %.1f',a));
end
yline(50,'--','HandleVisibility','off');
xlabel('Time (s)'); ylabel('Frequency (Hz)');
title('Fixed PI gains under parameter variation');
legend('Location','best');

%% 6. Save outputs for reporting
save('LFC_PI_results.mat','Kp','Ki','t','d','Gcl','Cpi');
fprintf('\nDone. Check stability and plots. Use only these corrected results in the report.\n');
